package fes.aragon.dinamicasDos;

public class NodoDoble {
    
    private NodoDoble anterior,siguiente;
    private Object dato;

    public NodoDoble(Object dato) {
        this(dato,null,null);
    }

    public NodoDoble(Object dato,NodoDoble anterior, NodoDoble siguiente) {
        this.anterior = anterior;
        this.siguiente = siguiente;
        this.dato = dato;
    }

    public NodoDoble getAnterior() {
        return anterior;
    }

    public void setAnterior(NodoDoble anterior) {
        this.anterior = anterior;
    }

    public NodoDoble getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoDoble siguiente) {
        this.siguiente = siguiente;
    }

    public Object getDato() {
        return dato;
    }

    public void setDato(Object dato) {
        this.dato = dato;
    }
   
}
