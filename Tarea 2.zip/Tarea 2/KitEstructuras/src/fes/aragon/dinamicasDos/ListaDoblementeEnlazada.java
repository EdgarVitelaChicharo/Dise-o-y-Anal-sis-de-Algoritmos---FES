package fes.aragon.dinamicasDos;

import fes.aragon.dinamicasDos.NodoDoble;

public class ListaDoblementeEnlazada {
   
    private NodoDoble cabeza,cola;     
    protected int longitud=0;

    public ListaDoblementeEnlazada() {
        cabeza=cola=null;
    }
    
    public int getLongitud(){
        return longitud;
    }
    
    public boolean esVacia(){
        return cola==null;
    }
    
    public void agregarEnCabeza(Object dato){
        if(cabeza==null){
            cabeza = cola = new NodoDoble(dato);
        }else{
            NodoDoble nuevo=new NodoDoble(dato, null, cabeza);
            cabeza.setAnterior(nuevo);
            cabeza=nuevo;
        }
        longitud++;
    }
    
    public void agregarEnCola(Object dato){
        if(cabeza==null){
            cabeza = cola = new NodoDoble(dato);
        }else{
            NodoDoble nuevo=new NodoDoble(dato, cola, null);
            cola.setSiguiente(nuevo);
            cola=nuevo;
        }
        longitud++;
    }
    
    public void imprimirDesdeCabeza(){
        for (NodoDoble tmp = cabeza; tmp != null; tmp = tmp.getSiguiente()) {
            System.out.println(tmp.getDato());
        }   
    }
    
    public void imprimirDesdeCola(){
        for (NodoDoble tmp = cola; tmp != null; tmp = tmp.getAnterior()) {
            System.out.println(tmp.getDato());
        }   
    }
    
    public Object eliminarEnCabeza() {
        Object dato = cabeza.getDato();
        if (cabeza == cola) {
            cabeza=cola=null;
        }else{
            cabeza=cabeza.getSiguiente();
            cabeza.setAnterior(null);
        }       
        longitud--;
        return dato;
    }
    
    public Object eliminarEnCola() {
        Object dato = cola.getDato();
            if (cola == cabeza) {
                cola = cabeza = null;
            } else{
                cola=cola.getAnterior();
                cola.setSiguiente(null);
            }
        longitud--;
        return dato;
    }

    public boolean eliminar(Object dato) {
        boolean borrado = false;
        if (cabeza != null) {
            if (cabeza == cola && dato.equals(cabeza.getDato())) { 
                cabeza = cola = null;
                borrado = true; 
                longitud--;
            } else if (dato.equals(cabeza.getDato())) { 
                cabeza = cabeza.getSiguiente();
                cabeza.setAnterior(null);
                borrado = true;
                longitud--;
            } else if (dato.equals(cola.getDato())) {
                cola = cola.getAnterior();
                cola.setSiguiente(null);
                borrado = true;
                longitud--;
            } else {
                for (NodoDoble tmp = cabeza; tmp != null; tmp = tmp.getSiguiente()) {
                    if (dato.equals(tmp.getDato())) {
                        tmp.getAnterior().setSiguiente(tmp.getSiguiente());
                        tmp.getSiguiente().setAnterior(tmp.getAnterior());
                        borrado = true;
                        longitud--;
                    }
                }
            }
        }
        return borrado;
    }

    public boolean estaEnLista(Object dato) {
        NodoDoble tmp;
        for(tmp = cabeza; tmp !=null && !tmp.getDato().equals(dato); tmp=tmp.getSiguiente());
        
        return tmp != null;
    }
    
    public Object obtenerNodo(int indice){
        NodoDoble tmp=null;
        if(indice <= longitud){
            tmp=cabeza;
            for(int contador=0;contador<indice && tmp!=null;contador++,tmp=tmp.getSiguiente());
        }       
        if(tmp!=null){
            return tmp.getDato();
        }else{
            return null;
        }
    }
    
    public boolean insertarEnIndice(Object dato, int indice){
        NodoDoble tmp=null;
        if(indice <=longitud && indice > 0){
            tmp=cabeza;
            for (int contador = 1; contador < indice && tmp != null; contador++ , tmp = tmp.getSiguiente());
        }
        if(tmp != null){
            tmp.setDato(dato);
            return true;
        }else{
         return false;   
        }
    }
    
    public boolean eliminarEnIndice(int indice) {
        boolean borrado = false;
        if (indice <= longitud && indice > 0) {
            if (cabeza != null) {
                if (cabeza == cola && indice == 1) { 
                    cabeza = cola = null;
                    borrado = true; 
                    longitud--;
                } else if (indice == 1) { 
                    cabeza = cabeza.getSiguiente();
                    cabeza.setAnterior(null);
                    borrado = true; 
                    longitud--;
                } else if(indice == longitud){
                    cola = cola.getAnterior();
                    cola.setSiguiente(null);
                    borrado = true;
                    longitud--;
                }else{
                    NodoDoble tmp;
                    int contador = 1;
                    for(tmp = cabeza, contador = 1; tmp != null && contador < indice; tmp = tmp.getSiguiente(), contador++);
                    tmp.getAnterior().setSiguiente(tmp.getSiguiente());
                    tmp.getSiguiente().setAnterior(tmp.getAnterior());
                    borrado = true;
                    longitud--;
                }
            }
        }
        return borrado;
    }
}
