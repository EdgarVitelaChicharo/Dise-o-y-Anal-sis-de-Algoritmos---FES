package fes.aragon.inter;

public interface Cola <E>  {
    
    void borrar();
    boolean estaVacia();
    void insertar(E dato);
    E extraer();
    E elementoSuperior();
    
}
