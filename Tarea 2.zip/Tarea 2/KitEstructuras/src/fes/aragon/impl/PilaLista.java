
package fes.aragon.impl;

import fes.aragon.dinamicas.ListaSimple;
import fes.aragon.inter.Pila;

public class PilaLista<E> implements Pila<E>{
    
    private ListaSimple pila=new ListaSimple();
    private int longitud=0;

    public PilaLista(int longitud) {
        this.longitud=longitud;
    }

    public int getLongitud() {
        return longitud;
    }

    public void setLongitud(int longitud) {
        this.longitud = longitud;
    }
       
    
    @Override
    public void borrar() {
        pila=new ListaSimple();
    }

    @Override
    public boolean estaVacia() {
        return pila.esVacia();
    }

    @Override
    public void insertar(E dato) {
        if(pila.getLongitud()<longitud){
            pila.agregarEnCabeza(dato);
        }else{
            System.out.println("Fila llena");
        }
    }

    @Override
    public E extraer() {
        return (E)pila.eliminarEnCabeza();
    }

    @Override
    public E elementoSuperior() {
        Object tmp=pila.eliminarEnCabeza();
        pila.agregarEnCabeza(tmp);
        return (E)tmp;
    }
    
}
