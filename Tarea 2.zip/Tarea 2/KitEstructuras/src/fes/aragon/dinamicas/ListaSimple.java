package fes.aragon.dinamicas;

public class ListaSimple {
    protected Nodo cabeza, cola;
    protected int longitud=0;

    public ListaSimple() {
        cabeza = cola = null;
    }
    
    public int getLongitud() {
        return longitud;
    }
    
    public boolean esVacia(){
        return cabeza==null;
    }

    public void agregarEnCabeza(Object dato) {
        cabeza = new Nodo(dato, cabeza);
        if (cabeza == null) {
            cola = cabeza;
        }
        longitud++;
    }

    public void agregarEnCola(Object dato) {;
        if (cola == null) {
            cabeza = cola = new Nodo(dato);
        } else {
            cola.setSiguiente(new Nodo(dato));
            cola = cola.getSiguiente();
        }
        longitud++;
    }
    
    public void imprimirElementos() {
        for (Nodo tmp = cabeza; tmp != null; tmp = tmp.getSiguiente()) {
            System.out.println(tmp.getDato());
        }
    }

    public Object eliminarEnCabeza() {
        Object dato = 0;
        if (cabeza != null) {
            dato = cabeza.getDato();
            if (cabeza == cola) {
                cabeza = cola = null;
            } else {
                cabeza = cabeza.getSiguiente();
            }
            longitud--;
        }        
        return dato;
    }

    public Object eliminarEnCola() {
        Object dato = null;
        if (cola != null) {
            dato = cola.getDato();
            if (cola == cabeza) {
                cola = cabeza = null;
            } else {
                Nodo tmp;
                for (tmp = cabeza; tmp.getSiguiente() != cola; tmp = tmp.getSiguiente());
                cola = tmp;
                cola.setSiguiente(null);
            }
            longitud--;
        }
        return dato;
    }

    public boolean eliminar(Object dato) {
        boolean borrado = false;
        if (cabeza != null) {
            if (cabeza == cola && dato.equals(cabeza.getDato())) {
                cabeza = cola = null;
                borrado = true;
                longitud--;
            } else if (dato == cabeza.getDato()) {
                cabeza = cabeza.getSiguiente();
                borrado = true;
                longitud--;
            } else {
                Nodo prd, tmp;
                for (prd = cabeza, tmp = cabeza.getSiguiente();
                        tmp != null && !tmp.getDato().equals(dato);
                        prd = prd.getSiguiente(), tmp = tmp.getSiguiente());
                if (tmp != null) {
                    borrado = true;
                    longitud--;
                    prd.setSiguiente(tmp.getSiguiente());
                    if (tmp == cola) {
                        cola = prd;
                    }
                }
            }
        }
        return borrado;
    }

    public boolean estaEnLista(Object dato) {
        Nodo tmp;
        for (tmp = cabeza; tmp != null && !tmp.getDato().equals(dato); tmp.getSiguiente()) {

        }
        return tmp != null;
    }
    
    public Object obtenerNodo(int indice){
        Nodo tmp=null;
        if(indice <= longitud){
            tmp=cabeza;
            for(int contador=0;contador<indice && tmp!=null;contador++,tmp=tmp.getSiguiente());
        }       
        if(tmp!=null){
            return tmp.getDato();
        }else{
            return null;
        }
    }
    
    public boolean insertarEnIndice(Object dato, int indice){
        Nodo tmp=null;
        if(indice <= longitud){
            tmp=cabeza;
            for(int contador=0;contador<indice && tmp!=null;contador++,tmp=tmp.getSiguiente());
        }       
        if(tmp!=null){
            tmp.setDato(dato);
            return true;
        }else{
            return false;
        }
    }
    
    public boolean eliminarEnIndice(int indice) {
        boolean borrado = false;
        if (indice <= longitud) {
            if (cabeza != null) {
                if (cabeza == cola && indice == 0) {
                    cabeza = cola = null;
                    borrado = true;
                    longitud--;
                } else if (indice==0) {
                    cabeza = cabeza.getSiguiente();
                    borrado = true;
                    longitud--;
                } else {
                    Nodo prd, tmp;
                    int contador=1;
                    for (prd = cabeza, tmp = cabeza.getSiguiente();
                            contador<indice;                           
                            prd = prd.getSiguiente(), tmp = tmp.getSiguiente(),
                            contador++);
                    if (tmp != null) {
                        borrado = true;
                        longitud--;
                        prd.setSiguiente(tmp.getSiguiente());
                        if (tmp == cola) {
                            cola = prd;
                        }
                    }
                }
            }
        }
        return borrado;
    }

   public void eliminarRepetidos() {
        Nodo inicio = cabeza;
    while(inicio!=null) {
        Nodo avance = inicio;
        while(avance.getSiguiente()!= null) {
            if(inicio.getDato()== avance.getSiguiente().getDato()) {
                avance.setSiguiente(avance.getSiguiente().getSiguiente());
            } else {
                avance = avance.getSiguiente();
            }
        }
        inicio = inicio.getSiguiente();
    }
    }
    

}
