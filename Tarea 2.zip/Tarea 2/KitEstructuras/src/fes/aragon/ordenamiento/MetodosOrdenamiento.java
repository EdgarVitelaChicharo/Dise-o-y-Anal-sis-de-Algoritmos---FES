/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fes.aragon.ordenamiento;

import fes.aragon.dinamicas.ListaSimple;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;

/**
 *
 * @author Edgar
 */
public class MetodosOrdenamiento {
   
    public static void seleccion(ListaSimple lista){
        int min=0;
        for (int i = 0; i < lista.getLongitud(); i++) {
            min=i;
            for (int j = i+1; j < lista.getLongitud(); j++) {
                if((Integer)lista.obtenerNodo(j)<(Integer)lista.obtenerNodo(min)){
                    min=j;
                }
            }
            if(i!= min){
                Object tmp=lista.obtenerNodo(i);
                lista.insertarEnIndice(lista.obtenerNodo(min), i);
                lista.insertarEnIndice(tmp, min);
            }
        }
    }
    
    public static void burbuja (ListaSimple lista){
        for (int i = 1; i < lista.getLongitud(); i++) {
            for (int j = 0; j < lista.getLongitud() - i; j++) {
              if((Integer) lista.obtenerNodo(j) > 
                      (Integer) lista.obtenerNodo(j+1)){
                    Object tmp = lista.obtenerNodo(j);
                    lista.insertarEnIndice(lista.obtenerNodo(j+1), j);
                    lista.insertarEnIndice(tmp, j+1);
                }  
            }
        }
    }
    
    public static void seleccion(ListaSimple lista, JPanel lamina) {
        int min = 0;
        for (int i = 0; i < lista.getLongitud(); i++) {
            min = i;
            for (int j = i + 1; j < lista.getLongitud(); j++) {
                if ((Integer) lista.obtenerNodo(j) < (Integer) lista.obtenerNodo(min)) {
                    min = j;
                }
            }
            if (i != min) {
                Object tmp = lista.obtenerNodo(i);
                lista.insertarEnIndice(lista.obtenerNodo(min), i);
                lista.insertarEnIndice(tmp, min);
            }

            lamina.repaint();
            try {
                Thread.sleep(50);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }

        }
    }
    
    public static void burbuja (ListaSimple lista, JPanel lamina){
        for (int i = 1; i < lista.getLongitud(); i++) {
            for (int j = 0; j < lista.getLongitud() - i; j++) {
              if((Integer) lista.obtenerNodo(j) > 
                      (Integer) lista.obtenerNodo(j+1)){
                    Object tmp = lista.obtenerNodo(j);
                    lista.insertarEnIndice(lista.obtenerNodo(j+1), j);
                    lista.insertarEnIndice(tmp, j+1);
                }
              lamina.repaint();
                try {
                    Thread.sleep(50);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    public static void insercion(ListaSimple lista){
       for (int i = 0; i < lista.getLongitud(); i++) {
            Object aux = lista.obtenerNodo(i);

            while ((i > 0) && ((Integer) lista.obtenerNodo(i - 1) > (Integer) aux)) {
                lista.insertarEnIndice(lista.obtenerNodo(i - 1), i);
                i--;
            }
            lista.insertarEnIndice(aux, i);
        } 
    }

    public static void quicksort(ListaSimple lista, int izq, int der) {
        int pos = (int) lista.obtenerNodo(izq);
        int i = izq;
        int j = der;
        int aux;

        while (i < j) {

            while ((int) lista.obtenerNodo(i) <= pos && i < j) {
                i++;
            }

            while ((int) lista.obtenerNodo(j) > pos) {
                j--;
            }
            if (i < j) {
                aux = (int) lista.obtenerNodo(i);

                lista.insertarEnIndice(lista.obtenerNodo(j), i);
                lista.insertarEnIndice(aux, j);
            }
        }

        lista.insertarEnIndice(lista.obtenerNodo(j), izq);

        lista.insertarEnIndice(pos, j);
        if (izq < j - 1) {
            quicksort(lista, izq, j - 1);
        }
        if (j + 1 < der) {
            quicksort(lista, j + 1, der);
        }
    }
    
    public static void insercion(ListaSimple lista, JPanel lamina) {
        for (int i = 0; i < lista.getLongitud(); i++) {
            Object aux = lista.obtenerNodo(i);

            while ((i > 0) && ((Integer) lista.obtenerNodo(i - 1) > (Integer) aux)) {
                lista.insertarEnIndice(lista.obtenerNodo(i - 1), i);
                i--;
            }
            lista.insertarEnIndice(aux, i);
            lamina.repaint();
                try {
                    Thread.sleep(50);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
        }
    }
    
    public static void quicksort(ListaSimple lista, int izq, int der, JPanel lamina) {
        int pos = (int) lista.obtenerNodo(izq);
        int i = izq;
        int j = der;
        int aux;

        while (i < j) {

            while ((Integer) lista.obtenerNodo(i) <= pos && i < j) {
                i++;      
            }

            while ((Integer) lista.obtenerNodo(j) > pos) {
                j--;
            }
                if (i < j) {
                aux = (Integer) lista.obtenerNodo(i);
               
                lista.insertarEnIndice(lista.obtenerNodo(j), i);
                lista.insertarEnIndice(aux, j);
                
            }
        }

        lista.insertarEnIndice(lista.obtenerNodo(j), izq);
        lista.insertarEnIndice(pos, j);
        
        
        if (izq < j - 1) {       
            quicksort(lista, izq, j - 1,lamina);
            lamina.repaint();
            try {
                Thread.sleep(50);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }
        
        
        if (j + 1 < der) {          
            quicksort(lista, j + 1, der,lamina);
            lamina.repaint();
            try {
                Thread.sleep(50);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }
        
        
    }
    

}
