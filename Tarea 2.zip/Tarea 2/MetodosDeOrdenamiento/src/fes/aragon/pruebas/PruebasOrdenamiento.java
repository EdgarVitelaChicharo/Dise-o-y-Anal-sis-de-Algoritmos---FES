/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fes.aragon.pruebas;

import fes.aragon.dinamicas.ListaSimple;
import fes.aragon.ordenamiento.MetodosOrdenamiento;
import java.util.Random;

/**
 *
 * @author Edgar
 */
public class PruebasOrdenamiento {
    public static void main(String[] args) {
        
        Random rd = new Random();
        ListaSimple lista = new ListaSimple();
        
        for (int i = 0; i < 10; i++) {
            lista.agregarEnCola(rd.nextInt(200));
        }
        
        lista.imprimirElementos();
        
        System.out.println("--------------------");
        
        MetodosOrdenamiento.insercion(lista);
        lista.imprimirElementos();
        
    }
}
