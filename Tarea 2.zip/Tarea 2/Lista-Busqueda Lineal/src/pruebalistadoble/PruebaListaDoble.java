
package pruebalistadoble;

import fes.aragon.dinamicasDos.ListaDoblementeEnlazada;

public class PruebaListaDoble {
    
    public static void main(String[] args) {
        ListaDoblementeEnlazada lista = new ListaDoblementeEnlazada();
        lista.agregarEnCola(2);
        lista.agregarEnCola(5);
        lista.agregarEnCola(7);
        lista.agregarEnCola(25);
        lista.agregarEnCola(1);
        lista.imprimirDesdeCabeza();
        
        System.out.println("\n(っ◕‿◕)っ ∪ω∪ ●﹏● ∪︿∪ ⊂(◉‿◉)つ (づ｡◕‿‿◕｡)づ\n");
        
        System.out.println(lista.estaEnLista(2));
        
        System.out.println("\n(っ◕‿◕)っ ∪ω∪ ●﹏● ∪︿∪ ⊂(◉‿◉)つ (づ｡◕‿‿◕｡)づ\n");
        
        System.out.println(lista.obtenerNodo(0));
        
    }
    
}
